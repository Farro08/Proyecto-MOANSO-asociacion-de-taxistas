package models;

public class Usuario {
    private String user;
    private String contraseña;

    public Usuario() {
    }

    public Usuario(String user, String contraseña) {
        this.user = user;
        this.contraseña = contraseña;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    @Override
    public String toString() {
        return "Usuario{" + "user=" + user + ", contrase\u00f1a=" + contraseña + '}';
    }
    
    
}