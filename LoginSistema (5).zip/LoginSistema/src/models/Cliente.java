
package models;


public class Cliente {
     private String nombres;
     private String apellidos;
     private String dni;
     private String telefono;
     private String auto;
     private String placa;
     private String direccion;
     private String fecha;
     
     public Cliente (){
    
}

    public Cliente(String nombres, String apellidos, String dni, String telefono, String auto, String placa, String direccion, String fecha) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.dni = dni;
        this.telefono = telefono;
        this.auto = auto;
        this.placa = placa;
        this.direccion = direccion;
        this.fecha = fecha;
    }

    public Cliente(String nombres, String apellidos, String telefono, String auto, String placa, String direccion, String fecha) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.auto = auto;
        this.placa = placa;
        this.direccion = direccion;
        this.fecha = fecha;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getAuto() {
        return auto;
    }

    public void setAuto(String auto) {
        this.auto = auto;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    

}

                                            