
package models;

import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import models.Conexion;

public class ClienteDao {
    Conexion conectar = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    public List<Cliente> listar(){
        List<Cliente>listarCliente = new ArrayList<>();
        String sql = "select * from cliente";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Cliente cli = new Cliente();
                cli.setNombres(rs.getString(1));
                cli.setApellidos(rs.getString(2));
                cli.setDni(rs.getString(3));
                cli.setTelefono(rs.getString(4));
                cli.setAuto(rs.getString(5));
                cli.setPlaca(rs.getString(6));
                cli.setDireccion(rs.getString(7));
                listarCliente.add(cli);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return listarCliente;
    }
    public int agregar (Cliente c){
        String sql = "insert into auto values(null,?,?,?,?,?,1)";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, c.getNombres());
            ps.setString(2, c.getApellidos());
            ps.setString(3, c.getDni());
            ps.setString(4, c.getTelefono());
            ps.setString(5, c.getAuto());
            ps.setString(6, c.getPlaca());
            ps.setString(7, c.getDireccion());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error al agregar: "+e.getMessage());
        
        }
        return 1;
    }
    
}

