
package models;

import java.sql.Connection;
import java.sql.DriverManager;


public class Conexion {
    Connection con;
    public Connection getConnection(){
        String url = "jdbc:mysql://127.0.0.1:3306/Socios";
        String user = "root";
        String pass = "1234";
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url,user,pass);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
        return con;
        
    }
}