
package controllers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import models.Cliente;
import models.ClienteDao;
import views.Bienvenida;


public class ClienteControllers implements ActionListener{
    
    DefaultTableModel modeloTabla = new DefaultTableModel();
    Bienvenida vista = new Bienvenida();
    ClienteDao dao = new ClienteDao();
    
    public ClienteControllers (Bienvenida bienvenida){
        this.vista = bienvenida;
        this.vista.btnlistar.addActionListener(this);
        this.vista.btnagregar.addActionListener(this);
    }
   

    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource() == vista.btnlistar){
           listar(vista.tbcliente);
       }
       if(e.getSource() == vista.btnagregar){
           agregar();
       }
    }
    private void agregar(){
        String nombres = vista.txtnombres.getText();
        String apellidos = vista.txtapellidos.getText();
        String dni = vista.txtdni.getText();
        String telefono = vista.txttelefono.getText();
        String auto = vista.txtauto.getText();
        String placa = vista.txtplaca.getText();
        String direccion = vista.txtdireccion.getText();
        String fecha = vista.txtfecha.getText();
        Cliente c = new Cliente(nombres, apellidos, dni, telefono,auto,placa,direccion,fecha);
        int rpta = this.dao.agregar(c);
        if(rpta ==1){
            JOptionPane.showMessageDialog(vista, "Socio registrado con exito !!!");
        }else{
            JOptionPane.showMessageDialog(vista, "Error al registar Socio");
        }
             
    }
    private void listar(JTable tabla){
         this.modeloTabla = (DefaultTableModel)tabla.getModel();
         List<Cliente>listaCliente = this.dao.listar();
         Object[] objeto = new Object[8];
         for(int i=0;i<listaCliente.size();i++){
             objeto[0] = listaCliente.get(i).getNombres();
             objeto[1] = listaCliente.get(i).getApellidos();
             objeto[2] = listaCliente.get(i).getDni();
             objeto[3] = listaCliente.get(i).getTelefono();
             objeto[4] = listaCliente.get(i).getAuto();
             objeto[5] = listaCliente.get(i).getPlaca();
             objeto[6] = listaCliente.get(i).getDireccion();
             objeto[7] = listaCliente.get(i).getFecha();
             modeloTabla.addRow(objeto);
      }
      vista.tbcliente.setModel(modeloTabla);
    }
       
    
}
